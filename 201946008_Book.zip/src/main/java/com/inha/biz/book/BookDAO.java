package com.inha.biz.book;

public interface BookDAO {

	public void insertBook(BookVO vo);
}
