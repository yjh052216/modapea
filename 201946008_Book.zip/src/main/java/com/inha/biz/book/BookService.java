package com.inha.biz.book;

public interface BookService {

	public void insertBook(BookVO vo);
	
}
