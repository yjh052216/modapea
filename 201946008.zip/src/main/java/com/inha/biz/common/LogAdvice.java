package com.inha.biz.common;

public class LogAdvice {
	public void logging(){
		
		System.out.println("============================================");
		System.out.println(" inset �Լ� ȣ��");
		System.out.println("============================================");
		
	}

}
