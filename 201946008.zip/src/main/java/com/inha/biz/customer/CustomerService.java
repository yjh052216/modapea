package com.inha.biz.customer;

public interface CustomerService {
	
	public void insertCustomer(CustomerVO vo);
}
