package com.inha.biz.customer;

public interface CustomerDAO {

	
	public void insertCustomer(CustomerVO vo);
}
